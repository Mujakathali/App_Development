package com.example.hall_booking.model;

public enum TokenType {

    BEARER
}
